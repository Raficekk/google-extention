// Klik na ikonu v liště otevře postranní panel místo popupu.
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error(error));
