const form = document.getElementById('composer');
const input = document.getElementById('input');
const sendBtn = document.getElementById('send');
const status = document.getElementById('status');

const MAX_HEIGHT = 220;

function autoResize() {
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, MAX_HEIGHT) + 'px';
}

function syncSendState() {
  const hasContent = input.value.trim().length > 0;
  sendBtn.disabled = !hasContent;
}

function showStatus(message) {
  status.textContent = message;
  status.classList.add('is-visible');
  window.clearTimeout(showStatus._t);
  showStatus._t = window.setTimeout(() => {
    status.classList.remove('is-visible');
  }, 1800);
}

// Enter odešle, Shift+Enter řádkuje
input.addEventListener('keydown', (event) => {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

input.addEventListener('input', () => {
  autoResize();
  syncSendState();
});

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const value = input.value.trim();
  if (!value) return;

  // TODO: sem napoj skutečnou akci — např. chrome.runtime.sendMessage(...)
  // nebo fetch na tvůj endpoint. Zatím jen potvrzení do UI.
  console.log('Odesláno:', value);

  input.value = '';
  autoResize();
  syncSendState();
  showStatus('Odesláno.');
  input.focus();
});

autoResize();
syncSendState();
